// Pricing constants — all rates defined here for easy maintenance
export const PRICING = {
  API_CALLS_TIER1_LIMIT: 10_000,
  API_CALLS_TIER1_RATE: 0.01,   // $ per call, first 10,000
  API_CALLS_TIER2_RATE: 0.008,  // $ per call, above 10,000
  STORAGE_RATE_PER_GB: 0.25,    // $ per GB
  COMPUTE_RATE_PER_MINUTE: 0.05 // $ per minute
} as const;
