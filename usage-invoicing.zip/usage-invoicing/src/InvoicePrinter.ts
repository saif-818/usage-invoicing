import { Invoice } from "./types";

const SEPARATOR = "----------------------------";

function fmt(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export class InvoicePrinter {
  static printInvoice(invoice: Invoice): void {
    console.log(`\nInvoice for Customer: ${invoice.customerId}`);
    console.log(SEPARATOR);
    for (const item of invoice.lineItems) {
      console.log(`${item.label}: ${item.quantity} -> ${fmt(item.cost)}`);
    }
    console.log(SEPARATOR);
    console.log(`Total Due: ${fmt(invoice.total)}`);
  }

  static printSkipped(reason: string): void {
    console.log(`\nSkipped invalid entry: ${reason}`);
  }
}
