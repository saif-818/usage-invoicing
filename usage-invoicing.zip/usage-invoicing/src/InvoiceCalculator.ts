import { PRICING } from "./constants";
import { ValidUsageEntry, Invoice, InvoiceLineItem } from "./types";

export class InvoiceCalculator {
  static calculateApiCost(apiCalls: number): number {
    if (apiCalls <= PRICING.API_CALLS_TIER1_LIMIT) {
      return apiCalls * PRICING.API_CALLS_TIER1_RATE;
    }
    const tier1Cost = PRICING.API_CALLS_TIER1_LIMIT * PRICING.API_CALLS_TIER1_RATE;
    const tier2Cost = (apiCalls - PRICING.API_CALLS_TIER1_LIMIT) * PRICING.API_CALLS_TIER2_RATE;
    return tier1Cost + tier2Cost;
  }

  static calculateStorageCost(storageGb: number): number {
    return storageGb * PRICING.STORAGE_RATE_PER_GB;
  }

  static calculateComputeCost(computeMinutes: number): number {
    return computeMinutes * PRICING.COMPUTE_RATE_PER_MINUTE;
  }

  static buildInvoice(entry: ValidUsageEntry): Invoice {
    const apiCost = InvoiceCalculator.calculateApiCost(entry.API_Calls);
    const storageCost = InvoiceCalculator.calculateStorageCost(entry.Storage_GB);
    const computeCost = InvoiceCalculator.calculateComputeCost(entry.Compute_Minutes);
    const total = apiCost + storageCost + computeCost;

    const lineItems: InvoiceLineItem[] = [
      {
        label: "API Calls",
        quantity: `${entry.API_Calls} calls`,
        cost: apiCost,
      },
      {
        label: "Storage",
        quantity: `${entry.Storage_GB} GB`,
        cost: storageCost,
      },
      {
        label: "Compute Time",
        quantity: `${entry.Compute_Minutes} minutes`,
        cost: computeCost,
      },
    ];

    return { customerId: entry.CustomerId, lineItems, total };
  }
}
