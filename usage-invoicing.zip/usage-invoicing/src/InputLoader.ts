import * as fs from "fs";
import { RawUsageEntry, ValidUsageEntry } from "./types";

export interface LoadResult {
  valid: ValidUsageEntry[];
  skipped: { id: string; reason: string }[];
}

function isPositiveNumber(val: unknown): val is number {
  return typeof val === "number" && isFinite(val) && val >= 0;
}

function isNonEmptyString(val: unknown): val is string {
  return typeof val === "string" && val.trim().length > 0;
}

function validateEntry(
  raw: RawUsageEntry
): { entry: ValidUsageEntry } | { error: string } {
  const id = raw.CustomerId;

  if (!isNonEmptyString(id)) {
    return { error: "Missing or invalid CustomerId" };
  }

  const checks: Array<[string, unknown]> = [
    ["API_Calls", raw.API_Calls],
    ["Storage_GB", raw.Storage_GB],
    ["Compute_Minutes", raw.Compute_Minutes],
  ];

  for (const [field, value] of checks) {
    if (value === undefined || value === null) {
      return {
        error: `Missing or invalid fields for CustomerId: ${id} (field: ${field})`,
      };
    }
    if (!isPositiveNumber(value)) {
      return {
        error: `Missing or invalid fields for CustomerId: ${id} (field: ${field} = ${JSON.stringify(value)})`,
      };
    }
  }

  return {
    entry: {
      CustomerId: id,
      API_Calls: raw.API_Calls as number,
      Storage_GB: raw.Storage_GB as number,
      Compute_Minutes: raw.Compute_Minutes as number,
    },
  };
}

export class InputLoader {
  static load(filePath: string): LoadResult {
    const rawJson = fs.readFileSync(filePath, "utf-8");
    const parsed: unknown = JSON.parse(rawJson);

    if (!Array.isArray(parsed)) {
      throw new Error("JSON root must be an array.");
    }

    const valid: ValidUsageEntry[] = [];
    const skipped: { id: string; reason: string }[] = [];

    for (const item of parsed as RawUsageEntry[]) {
      const result = validateEntry(item);
      if ("entry" in result) {
        valid.push(result.entry);
      } else {
        const displayId = isNonEmptyString(item.CustomerId)
          ? item.CustomerId
          : "(unknown)";
        console.warn(`WARNING: Skipped invalid entry: ${result.error}`);
        skipped.push({ id: displayId, reason: result.error });
      }
    }

    return { valid, skipped };
  }
}
