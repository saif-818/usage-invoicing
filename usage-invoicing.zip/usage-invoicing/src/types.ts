export interface RawUsageEntry {
  CustomerId?: unknown;
  API_Calls?: unknown;
  Storage_GB?: unknown;
  Compute_Minutes?: unknown;
}

export interface ValidUsageEntry {
  CustomerId: string;
  API_Calls: number;
  Storage_GB: number;
  Compute_Minutes: number;
}

export interface InvoiceLineItem {
  label: string;
  quantity: string;
  cost: number;
}

export interface Invoice {
  customerId: string;
  lineItems: InvoiceLineItem[];
  total: number;
}
