import * as path from "path";
import { InputLoader } from "./InputLoader";
import { InvoiceCalculator } from "./InvoiceCalculator";
import { InvoicePrinter } from "./InvoicePrinter";

function main(): void {
  // Accept optional JSON file path via CLI argument (bonus requirement)
  const filePath = process.argv[2] ?? path.join(__dirname, "..", "usage-data.json");

  console.log(`Loading usage data from: ${filePath}\n`);

  const { valid, skipped } = InputLoader.load(filePath);

  // Print invoices for valid entries
  for (const entry of valid) {
    const invoice = InvoiceCalculator.buildInvoice(entry);
    InvoicePrinter.printInvoice(invoice);
  }

  // Print skipped entries
  for (const { reason } of skipped) {
    InvoicePrinter.printSkipped(reason);
  }

  console.log(`\n=== Summary: ${valid.length} invoiced, ${skipped.length} skipped ===`);
}

main();
