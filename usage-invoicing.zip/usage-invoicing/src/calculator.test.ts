/**
 * Light unit tests for InvoiceCalculator.
 * Run with: node dist/calculator.test.js
 */
import { InvoiceCalculator } from "./InvoiceCalculator";

let passed = 0;
let failed = 0;

function assert(description: string, actual: number, expected: number): void {
  const ok = Math.abs(actual - expected) < 0.0001;
  if (ok) {
    console.log(`  ✓ ${description}`);
    passed++;
  } else {
    console.error(`  ✗ ${description} — expected ${expected}, got ${actual}`);
    failed++;
  }
}

console.log("\n=== InvoiceCalculator Unit Tests ===\n");

// API Calls — within tier 1
assert("API 0 calls = $0.00", InvoiceCalculator.calculateApiCost(0), 0.0);
assert("API 5000 calls = $50.00", InvoiceCalculator.calculateApiCost(5000), 50.0);
assert("API 10000 calls = $100.00", InvoiceCalculator.calculateApiCost(10_000), 100.0);

// API Calls — crossing tier 2
// 10000*0.01 + 2000*0.008 = 100 + 16 = 116
assert("API 12000 calls = $116.00", InvoiceCalculator.calculateApiCost(12_000), 116.0);
// 10000*0.01 + 8000*0.008 = 100 + 64 = 164
assert("API 18000 calls = $164.00", InvoiceCalculator.calculateApiCost(18_000), 164.0);

// Storage
assert("Storage 0 GB = $0.00", InvoiceCalculator.calculateStorageCost(0), 0.0);
assert("Storage 40 GB = $10.00", InvoiceCalculator.calculateStorageCost(40), 10.0);
assert("Storage 60.5 GB = $15.13", InvoiceCalculator.calculateStorageCost(60.5), 15.125);

// Compute
assert("Compute 0 min = $0.00", InvoiceCalculator.calculateComputeCost(0), 0.0);
assert("Compute 100 min = $5.00", InvoiceCalculator.calculateComputeCost(100), 5.0);
assert("Compute 240 min = $12.00", InvoiceCalculator.calculateComputeCost(240), 12.0);

// Full invoice for CUST001: API 9500 calls, 40 GB, 100 min
// API: 9500*0.01 = 95, Storage: 40*0.25 = 10, Compute: 100*0.05 = 5 => total = 110
const inv1 = InvoiceCalculator.buildInvoice({
  CustomerId: "CUST001",
  API_Calls: 9500,
  Storage_GB: 40,
  Compute_Minutes: 100,
});
assert("CUST001 total = $110.00", inv1.total, 110.0);

// Full invoice for CUST002: API 12000, 60.5 GB, 240 min
// API: 10000*0.01 + 2000*0.008 = 116, Storage: 60.5*0.25 = 15.125, Compute: 240*0.05 = 12 => total = 143.125
const inv2 = InvoiceCalculator.buildInvoice({
  CustomerId: "CUST002",
  API_Calls: 12_000,
  Storage_GB: 60.5,
  Compute_Minutes: 240,
});
assert("CUST002 total = $143.13", inv2.total, 143.125);

console.log(`\nResults: ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
